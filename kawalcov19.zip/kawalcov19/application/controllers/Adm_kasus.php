<?php

class Adm_kasus extends CI_Controller {
 
	public function __construct() {
        parent::__construct();
        $this->load->model('M_kasus');
    }

    public function index() {
        $data['kasus'] = $this->M_kasus->getAllKasus();
        $this->load->view('adm_kasus', $data);
    }

    public function tambah() {
        $this->form_validation->set_rules('terkonfirmasi', 'Terkonfirmasi', 'required');
        $this->form_validation->set_rules('perawatan', 'Perawatan', 'required');
        $this->form_validation->set_rules('sembuh', 'Sembuh', 'required');
        $this->form_validation->set_rules('meninggal', 'Meninggal', 'required');
        $this->form_validation->set_rules('provinsi', 'Provinsi', 'required');
        $this->form_validation->set_rules('waktu', 'Waktu', 'required');

        if ($this->form_validation->run() == false) {
            $this->load->view('kasus_tambah');
        }else {
            $this->M_kasus->tambahDataKasus();
			redirect('adm_kasus');
        }
    }

    public function ubah($id) {
        $data['kasus'] = $this->M_kasus->getKasusById($id);

        $this->form_validation->set_rules('terkonfirmasi', 'Terkonfirmasi', 'required');
        $this->form_validation->set_rules('perawatan', 'Perawatan', 'required');
        $this->form_validation->set_rules('sembuh', 'Sembuh', 'required');
        $this->form_validation->set_rules('meninggal', 'Meninggal', 'required');
        $this->form_validation->set_rules('provinsi', 'Provinsi', 'required');
        $this->form_validation->set_rules('waktu', 'Waktu', 'required');

        if ($this->form_validation->run() == false) {
            $this->load->view('kasus_ubah', $data);
        }else {
            $this->M_kasus->ubahDataKasus($id);
			redirect('adm_kasus');
        }
    }

    public function hapus($id) {
        $this->M_kasus->hapusDataKasus($id);
		redirect('adm_kasus');
    }
}

?>