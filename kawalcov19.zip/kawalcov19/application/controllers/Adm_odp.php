<?php

class Adm_odp extends CI_Controller {
 
	public function __construct() {
        parent::__construct();
        $this->load->model('m_login');
    }

    public function index() {
        $this->load->view('adm_odp');
    }

    public function tambah() {
        $this->load->view('odp_tambah');
    }

    public function ubah() {
        $this->load->view('odp_ubah');
    }
}

?>