<?php

class Adm_odp extends CI_Controller {
 
	public function __construct() {
        parent::__construct();
        $this->load->model('M_odp');
    }

    public function index() {
        $this->load->view('adm_odp');
    }

    public function tambah() {
        $this->load->view('odp_tambah');
        $this->form_validation->set_rules('prosespemantauan', 'prosespemantauan', 'required');
        $this->form_validation->set_rules('selesaipemantuan', 'selesaipemantuan', 'required');
        $this->form_validation->set_rules('provinsi', 'Provinsi', 'required');
        $this->form_validation->set_rules('waktu', 'Waktu', 'required');

        if ($this->form_validation->run() == false) {
            $this->load->view('odp_tambah');
        }else {
            $this->M_odp->tambahDataOdp();
            redirect('odp_kasus');
        }

    }

    public function ubah($id) {
        $data['odp'] = $this->M_odp->getOdpById($id);

        $this->form_validation->set_rules('prosespemantauan', 'prosespemantauan', 'required');
        $this->form_validation->set_rules('selesaipemantuan', 'selesaipemantuan', 'required');
        $this->form_validation->set_rules('provinsi', 'Provinsi', 'required');
        $this->form_validation->set_rules('waktu', 'Waktu', 'required');

        if ($this->form_validation->run() == false) {
            $this->load->view('odp_ubah', $data);
        }else {
            $this->M_odp->ubahDataOdp($id);
            redirect('adm_odp');
        }
    }
    public function hapus($id) {
        $this->M_odp->hapusDataOdp($id);
        redirect('adm_Odp');
    }
}

?>