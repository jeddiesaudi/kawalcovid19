<?php

class Adm_odp extends CI_Controller {
 
	public function __construct() {
        parent::__construct();
        $this->load->model('M_odp');
    }

    public function index() {
        $data['odp'] = $this->M_odp->getAllOdp();
        $this->load->view('adm_odp', $data);
    }

    public function tambah() {
        $this->form_validation->set_rules('proses', 'Proses', 'required');
        $this->form_validation->set_rules('selesai', 'Selesai', 'required');
        $this->form_validation->set_rules('provinsi', 'Provinsi', 'required');
        $this->form_validation->set_rules('waktu', 'Waktu', 'required');
        $this->form_validation->set_rules('total', 'Total', 'required');

        if ($this->form_validation->run() == false) {
            $this->load->view('odp_tambah');
        }else {
            $this->M_odp->tambahDataOdp();
            redirect('adm_odp');
        }

    }

    public function ubah($id) {
        $data['odp'] = $this->M_odp->getOdpById($id);

        $this->form_validation->set_rules('proses', 'Proses', 'required');
        $this->form_validation->set_rules('selesai', 'Selesai', 'required');
        $this->form_validation->set_rules('provinsi', 'Provinsi', 'required');
        $this->form_validation->set_rules('waktu', 'Waktu', 'required');
        $this->form_validation->set_rules('total', 'Total', 'required');

        if ($this->form_validation->run() == false) {
            $this->load->view('odp_ubah', $data);
        }else {
            $this->M_odp->ubahDataOdp($id);
            redirect('adm_odp');
        }
    }
    public function hapus($id) {
        $this->M_odp->hapusDataOdp($id);
        redirect('adm_odp');
    }
}

?>