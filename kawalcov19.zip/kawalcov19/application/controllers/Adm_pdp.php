<?php

class Adm_pdp extends CI_Controller {
 
	public function __construct() {
        parent::__construct();
        $this->load->model('m_login');
    }

    public function index() {
        $this->load->view('adm_pdp');
    }

    public function tambah() {
        $this->load->view('pdp_tambah');
    }

    public function ubah() {
        $this->load->view('pdp_ubah');
    }
}

?>