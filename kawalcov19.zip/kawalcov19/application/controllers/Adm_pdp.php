<?php

class Adm_pdp extends CI_Controller {
 
	public function __construct() {
        parent::__construct();
        $this->load->model('M_pdp');
    }

    public function index() {
        $data['pdp'] = $this->M_pdp->getAllPdp();
        $this->load->view('adm_pdp', $data);
    }

    public function tambah() {
        $this->form_validation->set_rules('proses', 'proses', 'required');
        $this->form_validation->set_rules('selesai', 'selesai', 'required');
        $this->form_validation->set_rules('provinsi', 'provinsi', 'required');
        $this->form_validation->set_rules('waktu', 'waktu', 'required');
        $this->form_validation->set_rules('total', 'total', 'required');

        if ($this->form_validation->run() == false) {
            $this->load->view('pdp_tambah');
        }else {
            $this->M_pdp->tambahDataPdp();
            redirect('adm_pdp');
        }
    }

    public function ubah($id) {
        $data['pdp'] = $this->M_pdp->getPdpById($id);

        $this->form_validation->set_rules('proses', 'proses', 'required');
        $this->form_validation->set_rules('selesai', 'selesai', 'required');
        $this->form_validation->set_rules('provinsi', 'provinsi', 'required');
        $this->form_validation->set_rules('waktu', 'waktu', 'required');
        $this->form_validation->set_rules('total', 'total', 'required');

    if ($this->form_validation->run() == false) {
            $this->load->view('pdp_ubah', $data);
        }else {
            $this->M_pdp->ubahDataPdp($id);
            redirect('adm_pdp');
        }   
    }

    public function hapus($id) {
        $this->M_pdp->hapusDataPdp($id);
        redirect('adm_pdp');
    }
}

?>