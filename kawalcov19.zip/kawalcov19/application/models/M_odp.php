<?php

class M_kasus extends CI_model {
    public function getAllOdp() {
        return $this->db->get('odp')->result_array();
    }

    public function tambahDataOdp() {
        $data = [
            "prosespemantauan" => $this->input->post('prosespemantauan', true),
            "selesaipemantuan" => $this->input->post('selesaipemantuan', true),
            "provinsi" => $this->input->post('provinsi', true),
            "waktu" => $this->input->post('waktu', true),  
        ];

        $this->db->insert('odp', $data);
    }

    public function hapusDataOdp($id) {
        $this->db->where('id', $id);
        $this->db->delete('odp');
    }

    public function getKasusById($id) {
        return $this->db->get_where('odp', ['id' => $id])->row_array();
    }

    public function ubahDataOdp($id) {
        $data = [
			"prosespemantauan" => $this->input->post('prosespemantauan', true),
            "selesaipemantuan" => $this->input->post('selesaipemantuan', true),
            "provinsi" => $this->input->post('provinsi', true),
            "waktu" => $this->input->post('waktu', true), 
        ];
        
		$this->db->where('id', $id);
		$this->db->update('odp', $data);
    }
}

?>