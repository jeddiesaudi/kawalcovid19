<?php

class M_odp extends CI_model {
    public function getAllOdp() {
        return $this->db->get('odp')->result_array();
    }

    public function tambahDataOdp() {
        $data = [
            "proses" => $this->input->post('proses', true),
            "selesai" => $this->input->post('selesai', true),
            "provinsi" => $this->input->post('provinsi', true),
            "waktu" => $this->input->post('waktu', true),  
            "total" => $this->input->post('total', true),  
        ];

        $this->db->insert('odp', $data);
    }

    public function hapusDataOdp($id) {
        $this->db->where('id', $id);
        $this->db->delete('odp');
    }

    public function getOdpById($id) {
        return $this->db->get_where('odp', ['id' => $id])->row_array();
    }

    public function ubahDataOdp($id) {
        $data = [
			"proses" => $this->input->post('proses', true),
            "selesai" => $this->input->post('selesai', true),
            "provinsi" => $this->input->post('provinsi', true),
            "waktu" => $this->input->post('waktu', true), 
            "total" => $this->input->post('total', true), 
        ];
        
		$this->db->where('id', $id);
		$this->db->update('odp', $data);
    }
}

?>