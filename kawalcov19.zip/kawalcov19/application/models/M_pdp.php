<?php 

class M_pdp extends CI_model {
    public function getAllPdp() {
        return $this->db->get('pdp')->result_array();
    }

    public function tambahDataPdp() {
        $data = [
            "proses" => $this->input->post('proses', true),
            "selesai" => $this->input->post('selesai', true),
            "provinsi" => $this->input->post('provinsi', true),
            "waktu" => $this->input->post('waktu', true),
            "total" => $this->input->post('total', true),  
        ];

        $this->db->insert('pdp', $data);
    }

    public function hapusDataPdp($id) {
        $this->db->where('id', $id);
        $this->db->delete('pdp');
    }

    public function getPdpById($id) {
        return $this->db->get_where('pdp', ['id' => $id])->row_array();
    }

    public function ubahDataPdp($id) {
        $data = [
			"proses" => $this->input->post('proses', true),
            "selesai" => $this->input->post('selesai', true),
            "provinsi" => $this->input->post('provinsi', true),
            "waktu" => $this->input->post('waktu', true),
            "total" => $this->input->post('total', true),  
        ];
        
		$this->db->where('id', $id);
		$this->db->update('pdp', $data);
    }

}
 ?>