<?php

class M_kasus extends CI_model {
    public function getAllKasus() {
        return $this->db->get('kasus')->result_array();
    }

    public function tambahDataKasus() {
        $data = [
            "terkonfirmasi" => $this->input->post('terkonfirmasi', true),
            "perawatan" => $this->input->post('perawatan', true),
            "sembuh" => $this->input->post('sembuh', true),
            "meninggal" => $this->input->post('meninggal', true),
            "provinsi" => $this->input->post('provinsi', true),
            "waktu" => $this->input->post('waktu', true),  
        ];

        $this->db->insert('kasus', $data);
    }

    public function hapusDataKasus($id) {
        $this->db->where('id', $id);
        $this->db->delete('kasus');
    }

    public function getKasusById($id) {
        return $this->db->get_where('kasus', ['id' => $id])->row_array();
    }

    public function ubahDataKasus($id) {
        $data = [
			"terkonfirmasi" => $this->input->post('terkonfirmasi', true),
            "perawatan" => $this->input->post('perawatan', true),
            "sembuh" => $this->input->post('sembuh', true),
            "meninggal" => $this->input->post('meninggal', true),
            "provinsi" => $this->input->post('provinsi', true),
            "waktu" => $this->input->post('waktu', true), 
        ];
        
		$this->db->where('id', $id);
		$this->db->update('kasus', $data);
    }
}

?>